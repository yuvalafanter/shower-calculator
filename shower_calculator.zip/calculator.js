
let data = {};

fetch('mtibath_catalog.json')
  .then(res => res.json())
  .then(json => {
    data = json;
    loadOptions();
  });

function loadOptions() {
  ["model", "glass_type", "profile_color", "glass_thickness", "opening_type", "nano_coating", "towel_bar", "glass_cut"]
    .forEach(field => {
      const select = document.getElementById(field);
      data[field]?.forEach(opt => {
        const el = document.createElement("option");
        el.text = opt;
        select.add(el);
      });
    });
}

document.getElementById("form").onsubmit = function(e) {
  e.preventDefault();
  const form = new FormData(e.target);
  const model = form.get("model");
  let price = data.base_prices[model] || 0;

  const additions = {
    glass_type: { "חלבית": 200, "מעוטרת": 400 },
    profile_color: { "שחור": 200, "זהב": 300 },
    nano_coating: { "כולל": 250 },
    towel_bar: { "כולל": 180 },
    glass_cut: { "חיתוך בהתאמה": 220 }
  };

  Object.keys(additions).forEach(key => {
    const value = form.get(key);
    price += additions[key]?.[value] || 0;
  });

  document.getElementById("result").innerText = `מחיר סופי: ₪${price}`;
  document.getElementById("preview").src = data.preview_images[model];
};
